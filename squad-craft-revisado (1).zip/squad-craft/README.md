# Squad Craft

Chat de voz privado por código. Node.js + WebSocket (sinalização) + WebRTC (áudio direto entre as pessoas). A interface usa React via CDN e Babel no navegador; não há etapa de build.
Sem contas: a pessoa escolhe nome e avatar, cria uma sala, recebe um código e envia aos amigos. Quem não tem o código não encontra a sala (não existe lista, busca nem página pública de salas).

## 1. Instalar e rodar no seu computador
Requisito: [Node.js 18+](https://nodejs.org).
```bash
npm install
cp .env.example .env      # no Windows: copy .env.example .env
npm start
```
Abra http://localhost:3000. Para testar a voz, abra em duas abas (use fones para não dar eco), crie a sala em uma e entre com o código na outra.
O navegador só libera o microfone em `localhost` ou em **HTTPS**. Para testar com o celular na mesma rede você precisa de HTTPS (veja a seção 2).

Testes automáticos do servidor: `npm test` (requer que `npm install` tenha terminado sem erros).

## 2. Publicar na internet
O site precisa de **HTTPS** (obrigatório para o microfone) e de suporte a **WebSocket**.

**Opção fácil: Render, Railway ou Fly.io**
1. Extraia o ZIP e envie a pasta `squad-craft` para um repositório GitHub. Não envie o arquivo `.env` nem segredos.
2. Na Render, crie um **New → Web Service** e conecte o repositório.
3. Configure Runtime **Node**, Build Command `npm install` e Start Command `npm start`.
4. Configure `MAX_ROOM_USERS=12` e `TRUST_PROXY=true` somente se a hospedagem estiver atrás de um proxy confiável que substitui o cabeçalho `X-Forwarded-For`. Configure as variáveis TURN apenas depois de ter um serviço TURN real.
5. Configure Health Check Path como `/healthz` e publique.
6. Abra a URL HTTPS gerada. O microfone exige HTTPS (exceto em `localhost`) e a hospedagem precisa permitir WebSocket.

**Opção VPS (Ubuntu) com Nginx**
```bash
sudo apt install nginx certbot python3-certbot-nginx
# rode o app com pm2:  npm i -g pm2 && pm2 start server.js --name squad-craft
```
Bloco do Nginx (depois `sudo certbot --nginx -d seudominio.com`):
```nginx
server {
  server_name seudominio.com;
  location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $remote_addr;
    proxy_read_timeout 3600s;
  }
}
```

## 3. Configurar o TURN (pessoas em redes diferentes)
Só com STUN, a chamada falha para muita gente (4G, Wi-Fi de empresa/escola, CGNAT). O TURN retransmite o áudio nesses casos.
Render/Railway **não** servem para TURN (precisa de portas UDP): use um **VPS** (qualquer um com IP público) ou um serviço de TURN pronto.

**Opção A: seu próprio coturn (grátis, recomendado)**
1. No VPS: `sudo apt install coturn`, depois edite `/etc/turnserver.conf` com base em `coturn/turnserver.conf` (troque `SEU_DOMINIO`, `IP_PUBLICO_DO_SERVIDOR` e o segredo).
2. Em `/etc/default/coturn`, deixe `TURNSERVER_ENABLED=1`. Inicie: `sudo systemctl enable --now coturn`.
3. Libere no firewall: **3478 TCP+UDP, 5349 TCP+UDP e 49160-49200 UDP**.
4. No `.env` (ou nas variáveis da hospedagem) do site:
   ```
   TURN_URLS=turn:seudominio.com:3478?transport=udp,turn:seudominio.com:3478?transport=tcp
   TURN_SECRET=o-mesmo-segredo-do-turnserver.conf
   ```
   O servidor gera credenciais temporárias para cada entrada na sala, sem expor senha fixa.
   Para `turns:` na porta 5349, ative o certificado TLS no `turnserver.conf` e acrescente a URL `turns:seudominio.com:5349?transport=tcp`.

**Opção B: serviço pronto (Metered, Twilio, Cloudflare etc.)**: copie as URLs para `TURN_URLS` e o usuário/senha para `TURN_USER` e `TURN_PASS` (deixe `TURN_SECRET` vazio).

**Como conferir se o TURN funciona:** abra https://webrtc.github.io/samples/src/content/peerconnection/trickle-ice/, informe sua URL TURN, usuário e senha e clique em *Gather candidates*. Precisa aparecer pelo menos um candidato do tipo `relay`. Com `TURN_SECRET`, o usuário/senha de teste podem ser gerados por: `node -e "const c=require('crypto');const u=String(Math.floor(Date.now()/1000)+3600);console.log(u,c.createHmac('sha1','SEU_SEGREDO').update(u).digest('base64'))"`.

## 4. Como funciona e limites
- Código com 12 caracteres aleatórios (60 bits, `crypto.randomBytes`), validado no servidor. 6 tentativas erradas por IP bloqueiam por 10 minutos.
- Criador = administrador (expulsar, silenciar, encerrar). Se ele sair de propósito, a administração passa ao participante mais antigo; se só cair a conexão, recupera ao reconectar.
- Salas ficam na memória: reiniciar o servidor derruba todas. Para escalar em várias instâncias seria preciso Redis.
- As pessoas se conectam em malha (cada uma com cada uma); funciona bem para grupos pequenos (até uns 8–12).
- Quem é expulso pode voltar se ainda tiver o código. Para bloquear de vez, encerre a sala e crie outra.
- No iPhone, o Safari ignora o controle de volume individual de elementos de áudio; o resto funciona.

## 5. Estado dos testes
- Testado automaticamente (`npm test`): criação de sala, formato do código, entrada por código, código inválido, relé de sinalização, permissões de admin, limite de lotação, reconexão de admin, transferência de admin, encerramento, anti-adivinhação e geração de credenciais TURN.
- **Estado desta cópia revisada:** não foi possível instalar `ws` neste ambiente, então `npm test` não pôde ser executado aqui. Também não foi possível testar navegador, chamada WebRTC real, TURN real ou aparelhos Android/iPhone. Faça um teste com dois aparelhos em redes diferentes (um no Wi-Fi e outro no 4G) antes de divulgar.
