// Squad Craft - servidor HTTP estático + sinalização WebSocket para WebRTC
const fs = require('fs');
const path = require('path');
const http = require('http');
const crypto = require('crypto');
const { WebSocketServer } = require('ws');

// Carrega .env sem depender de pacote extra
try {
  for (const l of fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split(/\r?\n/)) {
    const m = l.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
} catch (e) {}

const env = (k, d = '') => process.env[k] || d;
const list = (s) => String(s || '').split(',').map((x) => x.trim()).filter(Boolean);
const MAX = parseInt(env('MAX_ROOM_USERS', '12'), 10);
const TRUST = env('TRUST_PROXY') === 'true';
const PUB = path.join(__dirname, 'public');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };

const rooms = new Map(); // código -> sala. Nunca é listado nem exposto por HTTP.
const fails = new Map(); // ip -> tentativas erradas
const creates = new Map(); // ip -> criações de sala
const ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // 32 símbolos, sem 0/O/1/I
const token = () => crypto.randomBytes(16).toString('hex');
const safeEq = (a, b) => {
  const h = (x) => crypto.createHash('sha256').update(String(x)).digest();
  return crypto.timingSafeEqual(h(a), h(b));
};

function genCode() {
  let c;
  do {
    const b = crypto.randomBytes(12); // 12 símbolos x 5 bits = 60 bits (256 % 32 == 0, sem viés)
    const s = Array.from(b, (x) => ALPHA[x % 32]).join('');
    c = `${s.slice(0, 4)}-${s.slice(4, 8)}-${s.slice(8)}`;
  } while (rooms.has(c));
  return c;
}
function norm(s) {
  const t = String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  return t.length === 12 ? `${t.slice(0, 4)}-${t.slice(4, 8)}-${t.slice(8)}` : '';
}
function iceServers() {
  const s = [{ urls: list(env('STUN_URLS', 'stun:stun.l.google.com:19302')) }];
  const turn = list(env('TURN_URLS') || env('TURN_URL'));
  if (turn.length) {
    if (env('TURN_SECRET')) { // credenciais temporárias no formato do coturn (use-auth-secret)
      const user = String(Math.floor(Date.now() / 1000) + parseInt(env('TURN_TTL_SECONDS', '86400'), 10));
      const cred = crypto.createHmac('sha1', env('TURN_SECRET')).update(user).digest('base64');
      s.push({ urls: turn, username: user, credential: cred });
    } else if (env('TURN_USER')) s.push({ urls: turn, username: env('TURN_USER'), credential: env('TURN_PASS') });
  }
  return s;
}
function hit(map, ip, limit, windowMs) {
  const now = Date.now();
  const e = map.get(ip);
  if (!e || e.reset < now) { map.set(ip, { n: 1, reset: now + windowMs }); return false; }
  return ++e.n > limit;
}
const isBlocked = (map, ip, limit) => { const e = map.get(ip); return !!e && e.reset > Date.now() && e.n >= limit; };

const send = (ws, o) => ws.readyState === 1 && ws.send(JSON.stringify(o));
const pub = (c) => ({ id: c.id, name: c.name, avatar: c.avatar, muted: !!c.muted, forced: !!c.forced, admin: !!c.admin });
const toRoom = (room, o, except) => room.clients.forEach((c) => c !== except && send(c, o));

function enter(ws, room, admin, name, avatar) {
  if (room.clients.size >= MAX) return send(ws, { type: 'error', msg: 'Sala cheia' });
  clearTimeout(room.timer);
  Object.assign(ws, { room, admin, muted: false, forced: false,
    name: String(name || '').trim().slice(0, 24) || 'Convidado', avatar: String(avatar || '🎧').slice(0, 8) });
  const others = [...room.clients.values()].map(pub);
  room.clients.set(ws.id, ws);
  send(ws, { type: 'joined', id: ws.id, code: room.code, admin, adminToken: admin ? room.adminToken : undefined, peers: others, ice: iceServers() });
  toRoom(room, { type: 'peer-joined', peer: pub(ws) }, ws);
}
function leave(ws, explicit) {
  const room = ws.room; if (!room) return;
  ws.room = null; room.clients.delete(ws.id);
  toRoom(room, { type: 'peer-left', id: ws.id });
  if (!room.clients.size) { room.timer = setTimeout(() => rooms.delete(room.code), 120000); return; }
  if (explicit && ws.admin) { // admin saiu de propósito: passa a administração ao participante mais antigo
    const n = room.clients.values().next().value;
    n.admin = true; room.adminToken = token();
    send(n, { type: 'promoted', adminToken: room.adminToken });
    toRoom(room, { type: 'peer-admin', id: n.id });
  }
}

function handler(req, res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Permissions-Policy', 'microphone=(self)');
  let p;
  try { p = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch (e) { res.writeHead(400); return res.end(); }
  if (p === '/healthz') return res.end('ok');
  const f = path.normalize(path.join(PUB, p === '/' ? '/index.html' : p));
  if (!f.startsWith(PUB + path.sep)) { res.writeHead(403); return res.end(); }
  fs.readFile(f, (e, d) => {
    if (e) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream' });
    res.end(d);
  });
}

function createServer() {
  const server = http.createServer(handler);
  const wss = new WebSocketServer({ server, path: '/ws', maxPayload: 64 * 1024 });
  const online = () => wss.clients.forEach((c) => send(c, { type: 'online', n: wss.clients.size }));

  wss.on('connection', (ws, req) => {
    ws.id = crypto.randomBytes(8).toString('hex');
    ws.ip = (TRUST && String(req.headers['x-forwarded-for'] || '').split(',')[0].trim()) || req.socket.remoteAddress;
    ws.room = null; ws.msgs = 0;
    online();
    const tick = setInterval(() => (ws.msgs = 0), 1000);
    ws.on('message', (raw) => {
      if (++ws.msgs > 500) return; // folga para rajadas de ICE candidates
      let m; try { m = JSON.parse(raw); } catch (e) { return; }
      if (!m || typeof m !== 'object') return;
      const room = ws.room;
      switch (m.type) {
        case 'create': {
          if (room) return;
          if (hit(creates, ws.ip, 20, 3600000)) return send(ws, { type: 'error', msg: 'Muitas salas criadas. Tente mais tarde.' });
          const r = { code: genCode(), adminToken: token(), clients: new Map(), timer: null };
          rooms.set(r.code, r); enter(ws, r, true, m.name, m.avatar); break;
        }
        case 'join': {
          if (room) return;
          if (isBlocked(fails, ws.ip, 6)) return send(ws, { type: 'error', msg: 'Muitas tentativas. Aguarde alguns minutos.' });
          const r = rooms.get(norm(m.code));
          if (!r) { hit(fails, ws.ip, 6, 600000); return send(ws, { type: 'error', msg: 'Código inválido ou sala inexistente' }); }
          enter(ws, r, typeof m.adminToken === 'string' && safeEq(m.adminToken, r.adminToken), m.name, m.avatar); break;
        }
        case 'signal': {
          const t = room && room.clients.get(m.to);
          if (t && m.data && typeof m.data === 'object') send(t, { type: 'signal', from: ws.id, data: m.data }); break;
        }
        case 'state':
          if (room && !ws.forced) { ws.muted = !!m.muted; toRoom(room, { type: 'peer-state', id: ws.id, muted: ws.muted, forced: false }); } break;
        case 'kick': case 'mute': {
          if (!room || !ws.admin) return;
          const t = room.clients.get(m.id); if (!t || t === ws) return;
          if (m.type === 'kick') { send(t, { type: 'kicked' }); leave(t); break; }
          t.forced = !!m.value; if (t.forced) t.muted = true;
          send(t, { type: 'force-mute', value: t.forced });
          toRoom(room, { type: 'peer-state', id: t.id, muted: t.muted, forced: t.forced }); break;
        }
        case 'end': {
          if (!room || !ws.admin) return;
          rooms.delete(room.code); clearTimeout(room.timer);
          room.clients.forEach((c) => { send(c, { type: 'ended' }); c.room = null; }); break;
        }
        case 'leave': leave(ws, true); break;
      }
    });
    ws.on('close', () => { clearInterval(tick); leave(ws); online(); });
  });
  return server;
}

setInterval(() => { const n = Date.now(); [fails, creates].forEach((m) => m.forEach((e, k) => e.reset < n && m.delete(k))); }, 60000).unref();

if (require.main === module) {
  const PORT = env('PORT', '3000');
  createServer().listen(PORT, () => console.log(`Squad Craft rodando em http://localhost:${PORT}`));
}
module.exports = { createServer, norm, iceServers };
