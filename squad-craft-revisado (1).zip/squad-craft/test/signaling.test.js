// Testes do servidor de sinalização (sem navegador): node --test test/
process.env.TURN_URLS = 'turn:t.example.com:3478';
process.env.TURN_SECRET = 'segredo-de-teste';
process.env.MAX_ROOM_USERS = '3';
const test = require('node:test');
const assert = require('node:assert');
const crypto = require('crypto');
const WebSocket = require('ws');
const { createServer } = require('../server');

let server, url;
test.before(async () => { server = createServer(); await new Promise((r) => server.listen(0, r)); url = `ws://127.0.0.1:${server.address().port}/ws`; });
test.after(() => { server.closeAllConnections?.(); server.close(); });

function client() {
  const ws = new WebSocket(url); const q = []; const waiters = [];
  ws.on('message', (d) => { const m = JSON.parse(d); const i = waiters.findIndex((w) => w.t === m.type); if (i >= 0) waiters.splice(i, 1)[0].r(m); else q.push(m); });
  ws.opened = new Promise((r) => ws.on('open', r));
  ws.send_ = (o) => ws.send(JSON.stringify(o));
  ws.wait = (t, ms = 1500) => new Promise((res, rej) => {
    const i = q.findIndex((m) => m.type === t); if (i >= 0) return res(q.splice(i, 1)[0]);
    const w = { t, r: res }; waiters.push(w); setTimeout(() => rej(new Error('timeout ' + t)), ms);
  });
  ws.none = async (t) => { await new Promise((r) => setTimeout(r, 150)); assert.ok(!q.some((m) => m.type === t), 'não deveria receber ' + t); };
  return ws;
}
async function room() {
  const a = client(); await a.opened; a.send_({ type: 'create', name: 'Admin', avatar: '🦊' });
  const j = await a.wait('joined'); return { a, j };
}

test('criar sala gera código XXXX-XXXX-XXXX e token de admin', async () => {
  const { a, j } = await room();
  assert.match(j.code, /^[A-HJ-NP-Z2-9]{4}-[A-HJ-NP-Z2-9]{4}-[A-HJ-NP-Z2-9]{4}$/);
  assert.ok(j.admin && j.adminToken && j.peers.length === 0);
  a.close();
});
test('ICE inclui STUN e TURN com credencial temporária HMAC', async () => {
  const { a, j } = await room();
  const t = j.ice.find((s) => s.username);
  assert.ok(j.ice[0].urls.length && t);
  const expect = crypto.createHmac('sha1', 'segredo-de-teste').update(t.username).digest('base64');
  assert.strictEqual(t.credential, expect);
  assert.ok(+t.username > Date.now() / 1000);
  a.close();
});
test('entrar com código correto (aceita minúsculas e sem hífen) e sinalização P2P', async () => {
  const { a, j } = await room();
  const b = client(); await b.opened;
  b.send_({ type: 'join', code: j.code.toLowerCase().replace(/-/g, ''), name: 'Bia', avatar: '🐼' });
  const jb = await b.wait('joined');
  assert.strictEqual(jb.admin, false); assert.strictEqual(jb.adminToken, undefined);
  assert.strictEqual(jb.peers.length, 1); assert.strictEqual(jb.peers[0].name, 'Admin');
  const pj = await a.wait('peer-joined'); assert.strictEqual(pj.peer.name, 'Bia');
  b.send_({ type: 'signal', to: jb.peers[0].id, data: { sdp: { type: 'offer', sdp: 'x' } } });
  const s = await a.wait('signal'); assert.strictEqual(s.from, jb.id); assert.strictEqual(s.data.sdp.type, 'offer');
  a.close(); b.close();
});
test('sinal para quem está em outra sala não é entregue', async () => {
  const r1 = await room(), r2 = await room();
  r1.a.send_({ type: 'signal', to: r2.j.id, data: { candidate: {} } });
  await r2.a.none('signal'); r1.a.close(); r2.a.close();
});
test('não-admin não expulsa; admin silencia (forçado), libera e expulsa', async () => {
  const { a, j } = await room();
  const b = client(), c = client(); await b.opened; await c.opened;
  b.send_({ type: 'join', code: j.code, name: 'B' }); const jb = await b.wait('joined');
  c.send_({ type: 'join', code: j.code, name: 'C' }); const jc = await c.wait('joined');
  b.send_({ type: 'kick', id: jc.id }); await c.none('kicked');
  a.send_({ type: 'mute', id: jb.id, value: true });
  assert.strictEqual((await b.wait('force-mute')).value, true);
  b.send_({ type: 'state', muted: false }); // ignorado enquanto forçado
  const st = await c.wait('peer-state'); assert.ok(st.muted && st.forced);
  a.send_({ type: 'mute', id: jb.id, value: false });
  assert.strictEqual((await b.wait('force-mute')).value, false);
  a.send_({ type: 'kick', id: jc.id }); await c.wait('kicked');
  assert.strictEqual((await b.wait('peer-left')).id, jc.id);
  a.close(); b.close(); c.close();
});
test('limite de usuários por sala', async () => {
  const { a, j } = await room(); const cs = [];
  for (let i = 0; i < 2; i++) { const c = client(); await c.opened; c.send_({ type: 'join', code: j.code }); await c.wait('joined'); cs.push(c); }
  const x = client(); await x.opened; x.send_({ type: 'join', code: j.code });
  assert.strictEqual((await x.wait('error')).msg, 'Sala cheia');
  [a, x, ...cs].forEach((w) => w.close());
});
test('reconectar com adminToken recupera a administração', async () => {
  const { a, j } = await room(); a.close();
  const a2 = client(); await a2.opened; a2.send_({ type: 'join', code: j.code, adminToken: j.adminToken });
  assert.strictEqual((await a2.wait('joined')).admin, true);
  const imp = client(); await imp.opened; imp.send_({ type: 'join', code: j.code, adminToken: 'x'.repeat(40) });
  assert.strictEqual((await imp.wait('joined')).admin, false);
  a2.close(); imp.close();
});
test('admin que sai de propósito passa a administração', async () => {
  const { a, j } = await room(); const b = client(); await b.opened;
  b.send_({ type: 'join', code: j.code }); await b.wait('joined');
  a.send_({ type: 'leave' });
  const p = await b.wait('promoted'); assert.ok(p.adminToken && p.adminToken !== j.adminToken);
  a.close(); b.close();
});
test('encerrar sala desconecta todos e invalida o código', async () => {
  const { a, j } = await room(); const b = client(); await b.opened;
  b.send_({ type: 'join', code: j.code }); await b.wait('joined');
  b.send_({ type: 'end' }); await a.none('ended'); // não-admin não encerra
  a.send_({ type: 'end' }); await b.wait('ended'); await a.wait('ended');
  const c = client(); await c.opened; c.send_({ type: 'join', code: j.code });
  assert.strictEqual((await c.wait('error')).msg, 'Código inválido ou sala inexistente');
  a.close(); b.close(); c.close();
});
test('contagem online é enviada', async () => {
  const c = client(); await c.opened; assert.ok((await c.wait('online')).n >= 1); c.close();
});
test('bloqueia tentativas repetidas de adivinhar código (por IP)', async () => {
  const c = client(); await c.opened; let blocked = false;
  for (let i = 0; i < 10 && !blocked; i++) {
    c.send_({ type: 'join', code: 'ZZZZ-ZZZZ-ZZ' + (i % 10) + '2' });
    blocked = /Muitas tentativas/.test((await c.wait('error')).msg);
  }
  assert.ok(blocked); c.close();
});
